import { useState } from 'react';

interface AutoResponse {
  id: number;
  trigger: string;
  response: string;
  reactions: string[];
  createdBy: string;
  uses: number;
}

const initialResponses: AutoResponse[] = [
  { id: 1, trigger: 'hello', response: 'Hey there! 👋 Welcome to the server!', reactions: ['👋', '❤️'], createdBy: 'Admin#0001', uses: 156 },
  { id: 2, trigger: 'good morning', response: 'Good morning! Have a wonderful day! ☀️', reactions: ['☀️', '💛'], createdBy: 'Admin#0001', uses: 89 },
  { id: 3, trigger: 'gg', response: '', reactions: ['🔥', '🎮', '👏'], createdBy: 'Mod#1234', uses: 432 },
  { id: 4, trigger: 'lol', response: '', reactions: ['😂', '🤣'], createdBy: 'Admin#0001', uses: 678 },
  { id: 5, trigger: 'thanks', response: "You're welcome! 😊", reactions: ['❤️'], createdBy: 'Admin#0001', uses: 234 },
];

export function AutoResponder() {
  const [responses, setResponses] = useState<AutoResponse[]>(initialResponses);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTrigger, setNewTrigger] = useState('');
  const [newResponse, setNewResponse] = useState('');
  const [newReactions, setNewReactions] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredResponses = responses.filter(r =>
    r.trigger.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.response.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAdd = () => {
    if (!newTrigger.trim()) return;
    
    const newItem: AutoResponse = {
      id: Date.now(),
      trigger: newTrigger.toLowerCase(),
      response: newResponse,
      reactions: newReactions.split(',').map(r => r.trim()).filter(r => r),
      createdBy: 'You',
      uses: 0,
    };
    
    setResponses([...responses, newItem]);
    setNewTrigger('');
    setNewResponse('');
    setNewReactions('');
    setShowAddModal(false);
  };

  const handleDelete = (id: number) => {
    setResponses(responses.filter(r => r.id !== id));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-2xl p-6 border border-blue-500/30">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">💬 Auto Responder</h2>
            <p className="text-gray-400">Create automatic responses with emoji reactions</p>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-3 rounded-xl font-medium hover:opacity-90 transition-opacity flex items-center gap-2"
          >
            <span>➕</span> Add Response
          </button>
        </div>
      </div>

      {/* Info Card */}
      <div className="bg-[#12121a] rounded-2xl p-6 border border-purple-500/20">
        <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
          <span>ℹ️</span> How it works
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
          <div className="bg-[#1a1a24] rounded-xl p-4">
            <p className="text-purple-400 font-medium mb-1">Trigger</p>
            <p className="text-gray-400">When someone types the trigger word/phrase</p>
          </div>
          <div className="bg-[#1a1a24] rounded-xl p-4">
            <p className="text-pink-400 font-medium mb-1">Response</p>
            <p className="text-gray-400">Bot replies with your custom message (optional)</p>
          </div>
          <div className="bg-[#1a1a24] rounded-xl p-4">
            <p className="text-yellow-400 font-medium mb-1">Reactions</p>
            <p className="text-gray-400">Bot adds emoji reactions to the message</p>
          </div>
        </div>
        <div className="mt-4 bg-[#1a1a24] rounded-xl p-4">
          <p className="text-gray-400 text-sm">
            <span className="text-green-400 font-medium">Command: </span>
            <code className="text-purple-400">!ar add &lt;trigger&gt; | &lt;response&gt; | &lt;reactions&gt;</code>
          </p>
          <p className="text-gray-500 text-xs mt-2">
            Example: <code className="text-gray-400">!ar add hello | Hello there! | 👋,❤️,🎉</code>
          </p>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <input
          type="text"
          placeholder="Search auto responses..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-[#12121a] border border-purple-500/20 rounded-xl px-4 py-3 pl-12 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500/50"
        />
        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">🔍</span>
      </div>

      {/* Responses List */}
      <div className="bg-[#12121a] rounded-2xl p-6 border border-purple-500/20">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-white font-semibold text-lg">Active Responses ({filteredResponses.length})</h3>
        </div>

        <div className="space-y-4">
          {filteredResponses.map((item) => (
            <div
              key={item.id}
              className="bg-[#1a1a24] rounded-xl p-4 border border-transparent hover:border-purple-500/20 transition-all"
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-3 flex-wrap">
                    <span className="bg-purple-500/20 text-purple-400 px-3 py-1 rounded-lg text-sm font-mono">
                      "{item.trigger}"
                    </span>
                    <span className="text-gray-500 text-sm">by {item.createdBy}</span>
                    <span className="text-gray-600 text-xs">• {item.uses} uses</span>
                  </div>
                  
                  {item.response && (
                    <div className="flex items-center gap-2">
                      <span className="text-gray-500 text-sm">Response:</span>
                      <span className="text-white text-sm">{item.response}</span>
                    </div>
                  )}
                  
                  {item.reactions.length > 0 && (
                    <div className="flex items-center gap-2">
                      <span className="text-gray-500 text-sm">Reactions:</span>
                      <div className="flex gap-1">
                        {item.reactions.map((reaction, idx) => (
                          <span key={idx} className="text-xl bg-[#0a0a0f] px-2 py-1 rounded-lg">
                            {reaction}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                
                <button
                  onClick={() => handleDelete(item.id)}
                  className="text-red-400 hover:text-red-300 hover:bg-red-400/10 px-4 py-2 rounded-lg transition-colors text-sm"
                >
                  🗑️ Delete
                </button>
              </div>
            </div>
          ))}

          {filteredResponses.length === 0 && (
            <div className="text-center py-12">
              <span className="text-4xl mb-4 block">💬</span>
              <p className="text-gray-400">No auto responses found</p>
              <p className="text-gray-500 text-sm mt-1">Add one using the button above!</p>
            </div>
          )}
        </div>
      </div>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
          <div className="bg-[#12121a] rounded-2xl p-6 w-full max-w-md border border-purple-500/30">
            <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <span>➕</span> Add Auto Response
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="text-gray-400 text-sm block mb-2">Trigger Word/Phrase *</label>
                <input
                  type="text"
                  value={newTrigger}
                  onChange={(e) => setNewTrigger(e.target.value)}
                  placeholder="e.g., hello, good morning"
                  className="w-full bg-[#1a1a24] border border-purple-500/20 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500/50"
                />
              </div>
              
              <div>
                <label className="text-gray-400 text-sm block mb-2">Response Message (optional)</label>
                <textarea
                  value={newResponse}
                  onChange={(e) => setNewResponse(e.target.value)}
                  placeholder="e.g., Hello there! Welcome!"
                  rows={3}
                  className="w-full bg-[#1a1a24] border border-purple-500/20 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500/50 resize-none"
                />
              </div>
              
              <div>
                <label className="text-gray-400 text-sm block mb-2">Reactions (comma separated)</label>
                <input
                  type="text"
                  value={newReactions}
                  onChange={(e) => setNewReactions(e.target.value)}
                  placeholder="e.g., 👋, ❤️, 🎉"
                  className="w-full bg-[#1a1a24] border border-purple-500/20 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500/50"
                />
              </div>
            </div>
            
            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowAddModal(false)}
                className="flex-1 bg-gray-700 text-white px-4 py-3 rounded-xl font-medium hover:bg-gray-600 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleAdd}
                className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-3 rounded-xl font-medium hover:opacity-90 transition-opacity"
              >
                Add Response
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
