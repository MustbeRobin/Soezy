import { useState, useEffect } from 'react';

const stats = [
  { label: 'Total Servers', value: '1,247', icon: '🌐', change: '+12%' },
  { label: 'Active Users', value: '45,892', icon: '👥', change: '+8%' },
  { label: 'Commands Used', value: '127K', icon: '⚡', change: '+24%' },
  { label: 'Auto Responses', value: '89', icon: '💬', change: '+5' },
];

const recentActivity = [
  { action: 'Auto Response Triggered', user: 'User#1234', time: '2 min ago', type: 'response' },
  { action: 'Media Deleted & Logged', user: 'User#5678', time: '5 min ago', type: 'media' },
  { action: 'Sticker Stolen', user: 'Admin#0001', time: '12 min ago', type: 'sticker' },
  { action: 'Bad Word Detected', user: 'User#9012', time: '18 min ago', type: 'moderation' },
  { action: 'Ticket Created', user: 'User#3456', time: '25 min ago', type: 'ticket' },
];

const features = [
  { name: 'Auto Responder with Reactions', status: 'active', description: 'Trigger-based responses with emoji reactions' },
  { name: 'Media Delete Logs', status: 'active', description: 'Log deleted media with view option' },
  { name: 'Sticker Steal', status: 'active', description: 'Steal and save stickers from messages' },
  { name: 'Bad Word Filter', status: 'active', description: 'Auto-mute on bad word detection' },
  { name: 'NSFW Protection', status: 'active', description: 'Auto-ban NSFW content' },
  { name: 'AFK System', status: 'active', description: 'Track mentions while AFK' },
];

export function Dashboard() {
  const [uptime, setUptime] = useState('0d 0h 0m');

  useEffect(() => {
    const startTime = Date.now();
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const days = Math.floor(elapsed / (1000 * 60 * 60 * 24));
      const hours = Math.floor((elapsed % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((elapsed % (1000 * 60 * 60)) / (1000 * 60));
      setUptime(`${days}d ${hours}h ${minutes}m`);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <div 
            key={index}
            className="bg-[#12121a] rounded-2xl p-6 border border-purple-500/20 hover:border-purple-500/40 transition-all duration-300"
          >
            <div className="flex items-center justify-between mb-4">
              <span className="text-3xl">{stat.icon}</span>
              <span className="text-green-400 text-sm font-medium bg-green-400/10 px-2 py-1 rounded-lg">
                {stat.change}
              </span>
            </div>
            <h3 className="text-3xl font-bold text-white mb-1">{stat.value}</h3>
            <p className="text-gray-400 text-sm">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Uptime Card */}
      <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-2xl p-6 border border-purple-500/30">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-white font-semibold text-lg mb-1">Bot Uptime</h3>
            <p className="text-gray-400 text-sm">Time since last restart</p>
          </div>
          <div className="text-right">
            <p className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
              {uptime}
            </p>
            <div className="flex items-center gap-2 justify-end mt-1">
              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></div>
              <span className="text-green-400 text-sm">Running</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        <div className="bg-[#12121a] rounded-2xl p-6 border border-purple-500/20">
          <h3 className="text-white font-semibold text-lg mb-4 flex items-center gap-2">
            <span>📊</span> Recent Activity
          </h3>
          <div className="space-y-3">
            {recentActivity.map((activity, index) => (
              <div 
                key={index}
                className="flex items-center justify-between p-3 bg-[#1a1a24] rounded-xl hover:bg-[#1e1e28] transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full ${
                    activity.type === 'response' ? 'bg-blue-400' :
                    activity.type === 'media' ? 'bg-purple-400' :
                    activity.type === 'sticker' ? 'bg-pink-400' :
                    activity.type === 'moderation' ? 'bg-red-400' :
                    'bg-green-400'
                  }`}></div>
                  <div>
                    <p className="text-white text-sm font-medium">{activity.action}</p>
                    <p className="text-gray-500 text-xs">{activity.user}</p>
                  </div>
                </div>
                <span className="text-gray-500 text-xs">{activity.time}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Features Status */}
        <div className="bg-[#12121a] rounded-2xl p-6 border border-purple-500/20">
          <h3 className="text-white font-semibold text-lg mb-4 flex items-center gap-2">
            <span>✨</span> Features Status
          </h3>
          <div className="space-y-3">
            {features.map((feature, index) => (
              <div 
                key={index}
                className="flex items-center justify-between p-3 bg-[#1a1a24] rounded-xl"
              >
                <div>
                  <p className="text-white text-sm font-medium">{feature.name}</p>
                  <p className="text-gray-500 text-xs">{feature.description}</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                  feature.status === 'active' 
                    ? 'bg-green-400/10 text-green-400' 
                    : 'bg-yellow-400/10 text-yellow-400'
                }`}>
                  {feature.status === 'active' ? 'Active' : 'Inactive'}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
