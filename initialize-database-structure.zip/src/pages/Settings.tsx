import { useState } from 'react';

interface Setting {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  category: string;
}

const initialSettings: Setting[] = [
  // Moderation
  { id: 'badword', name: 'Bad Word Filter', description: 'Auto-mute users who use prohibited words', enabled: true, category: 'moderation' },
  { id: 'nsfw', name: 'NSFW Protection', description: 'Auto-ban users promoting NSFW content', enabled: true, category: 'moderation' },
  { id: 'modlogs', name: 'Moderation Logs', description: 'Log all moderation actions', enabled: true, category: 'moderation' },
  // Features
  { id: 'afk', name: 'AFK System', description: 'Allow users to set AFK status', enabled: true, category: 'features' },
  { id: 'confession', name: 'Anonymous Confessions', description: 'Allow anonymous confession posts', enabled: true, category: 'features' },
  { id: 'birthday', name: 'Birthday Wishes', description: 'Send automatic birthday wishes', enabled: true, category: 'features' },
  { id: 'ticket', name: 'Ticket System', description: 'Support ticket management', enabled: true, category: 'features' },
  { id: 'reminder', name: 'Reminders', description: 'Allow users to set reminders', enabled: true, category: 'features' },
  // Auto Responses
  { id: 'autorespond', name: 'Auto Responder', description: 'Automatic trigger-based responses', enabled: true, category: 'auto' },
  { id: 'autoreact', name: 'Auto Reactions', description: 'Add reactions to trigger messages', enabled: true, category: 'auto' },
  // Media
  { id: 'medialogs', name: 'Media Delete Logs', description: 'Log deleted images and videos', enabled: true, category: 'media' },
  { id: 'stickersteal', name: 'Sticker Steal', description: 'Allow stealing stickers', enabled: true, category: 'media' },
  { id: 'autodelete', name: 'Auto Delete Text', description: 'Auto-delete text messages in channels', enabled: false, category: 'media' },
];

export function Settings() {
  const [settings, setSettings] = useState<Setting[]>(initialSettings);
  const [prefix, setPrefix] = useState('!');
  const [confessionPrefix, setConfessionPrefix] = useState('#');
  const [activeCategory, setActiveCategory] = useState('all');

  const categories = [
    { id: 'all', name: 'All Settings', icon: '⚙️' },
    { id: 'moderation', name: 'Moderation', icon: '🛡️' },
    { id: 'features', name: 'Features', icon: '✨' },
    { id: 'auto', name: 'Auto Responses', icon: '💬' },
    { id: 'media', name: 'Media & Logs', icon: '📸' },
  ];

  const filteredSettings = activeCategory === 'all' 
    ? settings 
    : settings.filter(s => s.category === activeCategory);

  const toggleSetting = (id: string) => {
    setSettings(settings.map(s => 
      s.id === id ? { ...s, enabled: !s.enabled } : s
    ));
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'moderation': return 'from-red-500 to-orange-500';
      case 'features': return 'from-purple-500 to-pink-500';
      case 'auto': return 'from-blue-500 to-cyan-500';
      case 'media': return 'from-green-500 to-emerald-500';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-gray-600/20 to-purple-600/20 rounded-2xl p-6 border border-gray-500/30">
        <h2 className="text-2xl font-bold text-white mb-2">⚙️ Bot Settings</h2>
        <p className="text-gray-400">Configure your bot's behavior and features</p>
      </div>

      {/* Prefix Settings */}
      <div className="bg-[#12121a] rounded-2xl p-6 border border-purple-500/20">
        <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
          <span>📝</span> Prefix Settings
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="text-gray-400 text-sm block mb-2">Command Prefix</label>
            <div className="flex gap-3">
              <input
                type="text"
                value={prefix}
                onChange={(e) => setPrefix(e.target.value)}
                maxLength={3}
                className="flex-1 bg-[#1a1a24] border border-purple-500/20 rounded-xl px-4 py-3 text-white text-center font-mono text-lg focus:outline-none focus:border-purple-500/50"
              />
              <button className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-3 rounded-xl font-medium hover:opacity-90 transition-opacity">
                Save
              </button>
            </div>
            <p className="text-gray-500 text-xs mt-2">Example: {prefix}help, {prefix}kick, {prefix}mute</p>
          </div>
          <div>
            <label className="text-gray-400 text-sm block mb-2">Confession Prefix</label>
            <div className="flex gap-3">
              <input
                type="text"
                value={confessionPrefix}
                onChange={(e) => setConfessionPrefix(e.target.value)}
                maxLength={3}
                className="flex-1 bg-[#1a1a24] border border-purple-500/20 rounded-xl px-4 py-3 text-white text-center font-mono text-lg focus:outline-none focus:border-purple-500/50"
              />
              <button className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-3 rounded-xl font-medium hover:opacity-90 transition-opacity">
                Save
              </button>
            </div>
            <p className="text-gray-500 text-xs mt-2">Example: {confessionPrefix}I have a secret...</p>
          </div>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => setActiveCategory(category.id)}
            className={`px-4 py-2 rounded-xl font-medium whitespace-nowrap transition-all ${
              activeCategory === category.id
                ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white'
                : 'bg-[#12121a] text-gray-400 hover:text-white border border-purple-500/20'
            }`}
          >
            {category.icon} {category.name}
          </button>
        ))}
      </div>

      {/* Settings Grid */}
      <div className="bg-[#12121a] rounded-2xl p-6 border border-purple-500/20">
        <h3 className="text-white font-semibold text-lg mb-6">
          {categories.find(c => c.id === activeCategory)?.icon} {categories.find(c => c.id === activeCategory)?.name}
        </h3>

        <div className="space-y-4">
          {filteredSettings.map((setting) => (
            <div
              key={setting.id}
              className="flex items-center justify-between p-4 bg-[#1a1a24] rounded-xl border border-transparent hover:border-purple-500/20 transition-all"
            >
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-r ${getCategoryColor(setting.category)} flex items-center justify-center opacity-80`}>
                  <span className="text-white text-lg">
                    {setting.category === 'moderation' ? '🛡️' : 
                     setting.category === 'features' ? '✨' :
                     setting.category === 'auto' ? '💬' : '📸'}
                  </span>
                </div>
                <div>
                  <p className="text-white font-medium">{setting.name}</p>
                  <p className="text-gray-500 text-sm">{setting.description}</p>
                </div>
              </div>
              
              <button
                onClick={() => toggleSetting(setting.id)}
                className={`relative w-14 h-8 rounded-full transition-all duration-300 ${
                  setting.enabled 
                    ? 'bg-gradient-to-r from-purple-500 to-pink-500' 
                    : 'bg-gray-700'
                }`}
              >
                <div className={`absolute top-1 w-6 h-6 bg-white rounded-full shadow-lg transition-all duration-300 ${
                  setting.enabled ? 'left-7' : 'left-1'
                }`}></div>
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-[#12121a] rounded-2xl p-6 border border-purple-500/20">
        <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
          <span>⚡</span> Quick Actions
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <button className="bg-[#1a1a24] p-4 rounded-xl border border-purple-500/20 hover:border-purple-500/40 transition-all text-left">
            <span className="text-2xl mb-2 block">🔄</span>
            <p className="text-white font-medium">Restart Bot</p>
            <p className="text-gray-500 text-xs">Apply pending changes</p>
          </button>
          <button className="bg-[#1a1a24] p-4 rounded-xl border border-purple-500/20 hover:border-purple-500/40 transition-all text-left">
            <span className="text-2xl mb-2 block">📤</span>
            <p className="text-white font-medium">Export Config</p>
            <p className="text-gray-500 text-xs">Download settings file</p>
          </button>
          <button className="bg-[#1a1a24] p-4 rounded-xl border border-purple-500/20 hover:border-purple-500/40 transition-all text-left">
            <span className="text-2xl mb-2 block">📥</span>
            <p className="text-white font-medium">Import Config</p>
            <p className="text-gray-500 text-xs">Load settings from file</p>
          </button>
          <button className="bg-[#1a1a24] p-4 rounded-xl border border-red-500/20 hover:border-red-500/40 transition-all text-left">
            <span className="text-2xl mb-2 block">🗑️</span>
            <p className="text-white font-medium">Reset to Default</p>
            <p className="text-red-400 text-xs">Clear all settings</p>
          </button>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="bg-[#12121a] rounded-2xl p-6 border border-red-500/30">
        <h3 className="text-red-400 font-semibold mb-4 flex items-center gap-2">
          <span>⚠️</span> Danger Zone
        </h3>
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <p className="text-white font-medium">Clear All Data</p>
            <p className="text-gray-500 text-sm">This will delete all bot data including logs, settings, and configurations.</p>
          </div>
          <button className="bg-red-500/20 text-red-400 px-6 py-3 rounded-xl font-medium hover:bg-red-500/30 transition-colors whitespace-nowrap">
            Clear Data
          </button>
        </div>
      </div>
    </div>
  );
}
