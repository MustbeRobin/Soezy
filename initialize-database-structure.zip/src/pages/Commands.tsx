import { useState } from 'react';

const commandCategories = [
  {
    name: 'Moderation',
    icon: '🛡️',
    commands: [
      { name: '!mute', description: 'Timeout a user', usage: '!mute @user <duration> <reason>' },
      { name: '!unmute', description: 'Remove timeout from user', usage: '!unmute @user <reason>' },
      { name: '!kick', description: 'Kick a user from server', usage: '!kick @user <reason>' },
      { name: '!ban', description: 'Ban a user from server', usage: '!ban @user <reason>' },
      { name: '!unban', description: 'Unban a user', usage: '!unban <userID> <reason>' },
      { name: '!purge', description: 'Delete messages (with media)', usage: '!purge <amount> [@user]' },
      { name: '!clear', description: 'Delete text-only messages', usage: '!clear <amount> [@user]' },
    ]
  },
  {
    name: 'AFK System',
    icon: '😴',
    commands: [
      { name: '!afk', description: 'Set your AFK status', usage: '!afk <reason> [-g/-s] [duration]' },
      { name: '!afkremove', description: 'Remove your AFK status', usage: '!afkremove' },
      { name: '/afk-set-message', description: 'Set custom AFK message', usage: '/afk-set-message <message>' },
    ]
  },
  {
    name: 'Auto Responder',
    icon: '💬',
    commands: [
      { name: '!ar add', description: 'Add auto response with reactions', usage: '!ar add <trigger> | <response> | [reactions]' },
      { name: '!ar remove', description: 'Remove auto response', usage: '!ar remove <trigger>' },
      { name: '!ar list', description: 'List all auto responses', usage: '!ar list' },
      { name: '!ar clear', description: 'Clear all auto responses', usage: '!ar clear' },
    ]
  },
  {
    name: 'Sticker & Media',
    icon: '🎨',
    commands: [
      { name: '!steal', description: 'Steal sticker from message', usage: '!steal (reply to sticker)' },
      { name: '!stealemoji', description: 'Steal emoji from message', usage: '!stealemoji <emoji>' },
      { name: '!av', description: 'Get user avatar', usage: '!av [@user]' },
      { name: '!banner', description: 'Get user banner', usage: '!banner [@user]' },
    ]
  },
  {
    name: 'Reminders',
    icon: '⏰',
    commands: [
      { name: '!remind', description: 'Set a reminder', usage: '!remind <time> <message>' },
      { name: '!remind loop', description: 'Set repeating reminder', usage: '!remind loop <time> <message>' },
      { name: '!remind list', description: 'View active reminders', usage: '!remind list' },
      { name: '!remind cancel', description: 'Cancel a reminder', usage: '!remind cancel <id>' },
    ]
  },
  {
    name: 'Confession',
    icon: '🤫',
    commands: [
      { name: '#<message>', description: 'Post anonymous confession', usage: '#I love this server!' },
      { name: '!confess set', description: 'Set confession channel', usage: '!confess set #channel' },
      { name: '!confess logs', description: 'Set confession logs', usage: '!confess logs #channel' },
    ]
  },
  {
    name: 'Birthday',
    icon: '🎂',
    commands: [
      { name: '!birthday add', description: 'Add birthday', usage: '!birthday add @user YYYY-MM-DD' },
      { name: '!birthday remove', description: 'Remove birthday', usage: '!birthday remove @user' },
      { name: '!birthday list', description: 'List all birthdays', usage: '!birthday list' },
      { name: '!birthday setrole', description: 'Set birthday role', usage: '!birthday setrole @role' },
    ]
  },
  {
    name: 'Filters',
    icon: '🚫',
    commands: [
      { name: '!badword on/off', description: 'Toggle bad word filter', usage: '!badword on' },
      { name: '!badword list', description: 'View bad word list', usage: '!badword list' },
      { name: '!immune', description: 'Manage filter immunity', usage: '!immune badword/nsfw role/channel add/remove' },
    ]
  },
];

export function Commands() {
  const [selectedCategory, setSelectedCategory] = useState(commandCategories[0]);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCommands = selectedCategory.commands.filter(cmd =>
    cmd.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    cmd.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-2xl p-6 border border-purple-500/30">
        <h2 className="text-2xl font-bold text-white mb-2">⚡ Bot Commands</h2>
        <p className="text-gray-400">Browse all available commands organized by category</p>
      </div>

      {/* Search */}
      <div className="relative">
        <input
          type="text"
          placeholder="Search commands..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-[#12121a] border border-purple-500/20 rounded-xl px-4 py-3 pl-12 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500/50"
        />
        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">🔍</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Categories */}
        <div className="lg:col-span-1">
          <div className="bg-[#12121a] rounded-2xl p-4 border border-purple-500/20 space-y-2">
            {commandCategories.map((category) => (
              <button
                key={category.name}
                onClick={() => setSelectedCategory(category)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                  selectedCategory.name === category.name
                    ? 'bg-gradient-to-r from-purple-600/30 to-pink-600/30 text-white border border-purple-500/30'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <span className="text-lg">{category.icon}</span>
                <span className="font-medium text-sm">{category.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Commands List */}
        <div className="lg:col-span-3">
          <div className="bg-[#12121a] rounded-2xl p-6 border border-purple-500/20">
            <div className="flex items-center gap-3 mb-6">
              <span className="text-2xl">{selectedCategory.icon}</span>
              <h3 className="text-xl font-bold text-white">{selectedCategory.name}</h3>
              <span className="text-gray-500 text-sm">({filteredCommands.length} commands)</span>
            </div>

            <div className="space-y-4">
              {filteredCommands.map((command, index) => (
                <div
                  key={index}
                  className="bg-[#1a1a24] rounded-xl p-4 hover:bg-[#1e1e28] transition-colors border border-transparent hover:border-purple-500/20"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                    <code className="text-purple-400 font-mono font-semibold">{command.name}</code>
                    <span className="text-gray-400 text-sm">{command.description}</span>
                  </div>
                  <div className="bg-[#0a0a0f] rounded-lg px-3 py-2 mt-2">
                    <span className="text-gray-500 text-xs">Usage: </span>
                    <code className="text-gray-300 text-sm font-mono">{command.usage}</code>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
