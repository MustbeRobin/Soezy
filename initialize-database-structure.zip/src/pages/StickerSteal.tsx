import { useState } from 'react';

interface Sticker {
  id: number;
  name: string;
  url: string;
  format: 'png' | 'apng' | 'lottie';
  stolenFrom: string;
  stolenBy: string;
  stolenAt: string;
  saved: boolean;
}

const sampleStickers: Sticker[] = [
  {
    id: 1,
    name: 'pepehappy',
    url: 'https://picsum.photos/300/300?random=10',
    format: 'png',
    stolenFrom: 'Other Server',
    stolenBy: 'Admin#0001',
    stolenAt: '2024-01-15 14:32:21',
    saved: true
  },
  {
    id: 2,
    name: 'catjam',
    url: 'https://picsum.photos/300/300?random=11',
    format: 'apng',
    stolenFrom: 'Emoji Server',
    stolenBy: 'Mod#1234',
    stolenAt: '2024-01-14 12:15:44',
    saved: true
  },
  {
    id: 3,
    name: 'cool_dude',
    url: 'https://picsum.photos/300/300?random=12',
    format: 'png',
    stolenFrom: 'Gaming Hub',
    stolenBy: 'Admin#0001',
    stolenAt: '2024-01-13 10:05:33',
    saved: false
  },
  {
    id: 4,
    name: 'dance_party',
    url: 'https://picsum.photos/300/300?random=13',
    format: 'lottie',
    stolenFrom: 'Dance Server',
    stolenBy: 'User#5678',
    stolenAt: '2024-01-12 08:22:10',
    saved: true
  },
  {
    id: 5,
    name: 'thumbs_up',
    url: 'https://picsum.photos/300/300?random=14',
    format: 'png',
    stolenFrom: 'Meme Central',
    stolenBy: 'Admin#0001',
    stolenAt: '2024-01-11 16:45:55',
    saved: true
  },
  {
    id: 6,
    name: 'fire_emoji',
    url: 'https://picsum.photos/300/300?random=15',
    format: 'apng',
    stolenFrom: 'Fire Nation',
    stolenBy: 'Mod#9012',
    stolenAt: '2024-01-10 14:30:00',
    saved: false
  },
];

export function StickerSteal() {
  const [stickers, setStickers] = useState<Sticker[]>(sampleStickers);
  const [selectedSticker, setSelectedSticker] = useState<Sticker | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSavedOnly, setShowSavedOnly] = useState(false);

  const filteredStickers = stickers.filter(sticker => {
    const matchesSearch = sticker.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sticker.stolenFrom.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSaved = !showSavedOnly || sticker.saved;
    return matchesSearch && matchesSaved;
  });

  const toggleSave = (id: number) => {
    setStickers(stickers.map(s => 
      s.id === id ? { ...s, saved: !s.saved } : s
    ));
  };

  const getFormatBadge = (format: string) => {
    switch (format) {
      case 'png': return { color: 'bg-blue-500/20 text-blue-400', label: 'PNG' };
      case 'apng': return { color: 'bg-purple-500/20 text-purple-400', label: 'Animated' };
      case 'lottie': return { color: 'bg-pink-500/20 text-pink-400', label: 'Lottie' };
      default: return { color: 'bg-gray-500/20 text-gray-400', label: format };
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-pink-600/20 to-yellow-600/20 rounded-2xl p-6 border border-pink-500/30">
        <h2 className="text-2xl font-bold text-white mb-2">🎨 Sticker Steal</h2>
        <p className="text-gray-400">Steal and manage stickers from any message</p>
      </div>

      {/* How to Use */}
      <div className="bg-[#12121a] rounded-2xl p-6 border border-purple-500/20">
        <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
          <span>📖</span> How to Steal Stickers
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-[#1a1a24] rounded-xl p-4">
            <div className="text-2xl mb-2">1️⃣</div>
            <p className="text-white font-medium mb-1">Reply to a Message</p>
            <p className="text-gray-400 text-sm">Find a message with a sticker you like</p>
          </div>
          <div className="bg-[#1a1a24] rounded-xl p-4">
            <div className="text-2xl mb-2">2️⃣</div>
            <p className="text-white font-medium mb-1">Use the Command</p>
            <p className="text-gray-400 text-sm">Reply with <code className="text-purple-400">!steal</code></p>
          </div>
          <div className="bg-[#1a1a24] rounded-xl p-4">
            <div className="text-2xl mb-2">3️⃣</div>
            <p className="text-white font-medium mb-1">Sticker Saved!</p>
            <p className="text-gray-400 text-sm">Bot will add sticker to your server</p>
          </div>
        </div>
        <div className="mt-4 bg-[#1a1a24] rounded-xl p-4">
          <p className="text-gray-400 text-sm">
            <span className="text-green-400 font-medium">Commands: </span>
            <code className="text-purple-400">!steal</code> (stickers) • 
            <code className="text-purple-400 ml-2">!stealemoji &lt;emoji&gt;</code> (emojis)
          </p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Total Stolen', value: stickers.length.toString(), icon: '🎨' },
          { label: 'Saved to Server', value: stickers.filter(s => s.saved).length.toString(), icon: '💾' },
          { label: 'PNG Stickers', value: stickers.filter(s => s.format === 'png').length.toString(), icon: '🖼️' },
          { label: 'Animated', value: stickers.filter(s => s.format !== 'png').length.toString(), icon: '✨' },
        ].map((stat, index) => (
          <div key={index} className="bg-[#12121a] rounded-xl p-4 border border-purple-500/20">
            <div className="flex items-center gap-3">
              <span className="text-2xl">{stat.icon}</span>
              <div>
                <p className="text-white font-bold text-lg">{stat.value}</p>
                <p className="text-gray-500 text-xs">{stat.label}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <input
            type="text"
            placeholder="Search stickers..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#12121a] border border-purple-500/20 rounded-xl px-4 py-3 pl-12 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500/50"
          />
          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">🔍</span>
        </div>
        
        <button
          onClick={() => setShowSavedOnly(!showSavedOnly)}
          className={`px-6 py-3 rounded-xl font-medium transition-all flex items-center gap-2 ${
            showSavedOnly
              ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white'
              : 'bg-[#12121a] text-gray-400 hover:text-white border border-purple-500/20'
          }`}
        >
          <span>💾</span> {showSavedOnly ? 'Showing Saved' : 'Show Saved Only'}
        </button>
      </div>

      {/* Stickers Grid */}
      <div className="bg-[#12121a] rounded-2xl p-6 border border-purple-500/20">
        <h3 className="text-white font-semibold text-lg mb-6 flex items-center gap-2">
          <span>🎭</span> Stolen Stickers ({filteredStickers.length})
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {filteredStickers.map((sticker) => (
            <div
              key={sticker.id}
              className="bg-[#1a1a24] rounded-xl overflow-hidden border border-transparent hover:border-purple-500/30 transition-all group"
            >
              {/* Sticker Preview */}
              <div 
                className="relative aspect-square bg-[#0a0a0f] cursor-pointer overflow-hidden"
                onClick={() => setSelectedSticker(sticker)}
              >
                <img
                  src={sticker.url}
                  alt={sticker.name}
                  className="w-full h-full object-contain p-4 group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <span className="text-white text-sm font-medium">👁️ View</span>
                </div>
                <div className={`absolute top-2 right-2 px-2 py-1 rounded text-xs font-medium ${getFormatBadge(sticker.format).color}`}>
                  {getFormatBadge(sticker.format).label}
                </div>
                {sticker.saved && (
                  <div className="absolute top-2 left-2 text-green-400">
                    ✓
                  </div>
                )}
              </div>
              
              {/* Info */}
              <div className="p-3">
                <p className="text-white font-medium text-sm truncate">{sticker.name}</p>
                <p className="text-gray-500 text-xs truncate">From: {sticker.stolenFrom}</p>
                <button
                  onClick={() => toggleSave(sticker.id)}
                  className={`w-full mt-2 py-2 rounded-lg text-xs font-medium transition-all ${
                    sticker.saved
                      ? 'bg-green-500/20 text-green-400 hover:bg-green-500/30'
                      : 'bg-purple-500/20 text-purple-400 hover:bg-purple-500/30'
                  }`}
                >
                  {sticker.saved ? '✓ Saved' : '💾 Save to Server'}
                </button>
              </div>
            </div>
          ))}
        </div>

        {filteredStickers.length === 0 && (
          <div className="text-center py-12">
            <span className="text-4xl mb-4 block">🎨</span>
            <p className="text-gray-400">No stickers found</p>
            <p className="text-gray-500 text-sm mt-1">Use !steal command to steal stickers</p>
          </div>
        )}
      </div>

      {/* View Modal */}
      {selectedSticker && (
        <div 
          className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedSticker(null)}
        >
          <div 
            className="bg-[#12121a] rounded-2xl w-full max-w-md border border-purple-500/30 overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Sticker */}
            <div className="relative aspect-square bg-[#0a0a0f] p-8">
              <img
                src={selectedSticker.url}
                alt={selectedSticker.name}
                className="w-full h-full object-contain"
              />
              <button
                onClick={() => setSelectedSticker(null)}
                className="absolute top-4 right-4 w-10 h-10 bg-black/50 rounded-full flex items-center justify-center text-white hover:bg-black/70 transition-colors"
              >
                ✕
              </button>
              <div className={`absolute bottom-4 left-4 px-3 py-1 rounded-lg text-sm font-medium ${getFormatBadge(selectedSticker.format).color}`}>
                {getFormatBadge(selectedSticker.format).label}
              </div>
            </div>
            
            {/* Details */}
            <div className="p-6 space-y-4">
              <h3 className="text-xl font-bold text-white">{selectedSticker.name}</h3>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-500 mb-1">Stolen From</p>
                  <p className="text-white">{selectedSticker.stolenFrom}</p>
                </div>
                <div>
                  <p className="text-gray-500 mb-1">Stolen By</p>
                  <p className="text-white">{selectedSticker.stolenBy}</p>
                </div>
                <div>
                  <p className="text-gray-500 mb-1">Date</p>
                  <p className="text-white">{selectedSticker.stolenAt}</p>
                </div>
                <div>
                  <p className="text-gray-500 mb-1">Status</p>
                  <p className={selectedSticker.saved ? 'text-green-400' : 'text-yellow-400'}>
                    {selectedSticker.saved ? '✓ Saved to Server' : '⏳ Not Saved'}
                  </p>
                </div>
              </div>
              
              <div className="flex gap-3 pt-4 border-t border-purple-500/20">
                <a
                  href={selectedSticker.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-3 rounded-xl font-medium text-center hover:opacity-90 transition-opacity"
                >
                  ⬇️ Download
                </a>
                <button
                  onClick={() => {
                    toggleSave(selectedSticker.id);
                    setSelectedSticker({ ...selectedSticker, saved: !selectedSticker.saved });
                  }}
                  className={`flex-1 px-4 py-3 rounded-xl font-medium transition-colors ${
                    selectedSticker.saved
                      ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
                      : 'bg-green-500/20 text-green-400 hover:bg-green-500/30'
                  }`}
                >
                  {selectedSticker.saved ? '🗑️ Remove' : '💾 Save'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
