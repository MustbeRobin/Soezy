import { useState } from 'react';

interface MediaLog {
  id: number;
  type: 'image' | 'video' | 'gif' | 'sticker';
  url: string;
  thumbnail: string;
  user: string;
  userId: string;
  channel: string;
  deletedAt: string;
  deletedBy: string;
  reason: string;
}

const sampleLogs: MediaLog[] = [
  {
    id: 1,
    type: 'image',
    url: 'https://picsum.photos/800/600?random=1',
    thumbnail: 'https://picsum.photos/200/150?random=1',
    user: 'User#1234',
    userId: '123456789',
    channel: '#general',
    deletedAt: '2024-01-15 14:32:21',
    deletedBy: 'Auto-Mod',
    reason: 'NSFW Content Detected'
  },
  {
    id: 2,
    type: 'gif',
    url: 'https://picsum.photos/400/300?random=2',
    thumbnail: 'https://picsum.photos/200/150?random=2',
    user: 'User#5678',
    userId: '987654321',
    channel: '#memes',
    deletedAt: '2024-01-15 13:15:44',
    deletedBy: 'Mod#0001',
    reason: 'Spam'
  },
  {
    id: 3,
    type: 'video',
    url: 'https://picsum.photos/600/400?random=3',
    thumbnail: 'https://picsum.photos/200/150?random=3',
    user: 'User#9012',
    userId: '456789123',
    channel: '#media',
    deletedAt: '2024-01-15 12:05:33',
    deletedBy: 'Auto-Mod',
    reason: 'Bad Word in Caption'
  },
  {
    id: 4,
    type: 'image',
    url: 'https://picsum.photos/800/600?random=4',
    thumbnail: 'https://picsum.photos/200/150?random=4',
    user: 'User#3456',
    userId: '789123456',
    channel: '#art',
    deletedAt: '2024-01-15 11:22:10',
    deletedBy: 'Admin#0001',
    reason: 'Rule Violation'
  },
  {
    id: 5,
    type: 'sticker',
    url: 'https://picsum.photos/300/300?random=5',
    thumbnail: 'https://picsum.photos/150/150?random=5',
    user: 'User#7890',
    userId: '321654987',
    channel: '#chat',
    deletedAt: '2024-01-15 10:45:55',
    deletedBy: 'Auto-Mod',
    reason: 'Inappropriate Sticker'
  },
];

export function MediaLogs() {
  const [logs] = useState<MediaLog[]>(sampleLogs);
  const [selectedLog, setSelectedLog] = useState<MediaLog | null>(null);
  const [filterType, setFilterType] = useState<'all' | 'image' | 'video' | 'gif' | 'sticker'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredLogs = logs.filter(log => {
    const matchesType = filterType === 'all' || log.type === filterType;
    const matchesSearch = 
      log.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.channel.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.reason.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesSearch;
  });

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'image': return '🖼️';
      case 'video': return '🎬';
      case 'gif': return '🎞️';
      case 'sticker': return '🎨';
      default: return '📁';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'image': return 'from-blue-500 to-cyan-500';
      case 'video': return 'from-purple-500 to-pink-500';
      case 'gif': return 'from-green-500 to-emerald-500';
      case 'sticker': return 'from-yellow-500 to-orange-500';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-red-600/20 to-orange-600/20 rounded-2xl p-6 border border-red-500/30">
        <h2 className="text-2xl font-bold text-white mb-2">📸 Media Delete Logs</h2>
        <p className="text-gray-400">View and recover deleted media from your server</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Total Logged', value: '1,234', icon: '📊' },
          { label: 'Images', value: '856', icon: '🖼️' },
          { label: 'Videos', value: '234', icon: '🎬' },
          { label: 'GIFs & Stickers', value: '144', icon: '🎨' },
        ].map((stat, index) => (
          <div key={index} className="bg-[#12121a] rounded-xl p-4 border border-purple-500/20">
            <div className="flex items-center gap-3">
              <span className="text-2xl">{stat.icon}</span>
              <div>
                <p className="text-white font-bold text-lg">{stat.value}</p>
                <p className="text-gray-500 text-xs">{stat.label}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <input
            type="text"
            placeholder="Search by user, channel, or reason..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#12121a] border border-purple-500/20 rounded-xl px-4 py-3 pl-12 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500/50"
          />
          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">🔍</span>
        </div>
        
        <div className="flex gap-2 flex-wrap">
          {(['all', 'image', 'video', 'gif', 'sticker'] as const).map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-4 py-2 rounded-xl font-medium transition-all ${
                filterType === type
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white'
                  : 'bg-[#12121a] text-gray-400 hover:text-white border border-purple-500/20'
              }`}
            >
              {type === 'all' ? 'All' : getTypeIcon(type)} {type !== 'all' && type.charAt(0).toUpperCase() + type.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Logs Grid */}
      <div className="bg-[#12121a] rounded-2xl p-6 border border-purple-500/20">
        <h3 className="text-white font-semibold text-lg mb-6 flex items-center gap-2">
          <span>📋</span> Recent Deleted Media ({filteredLogs.length})
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredLogs.map((log) => (
            <div
              key={log.id}
              className="bg-[#1a1a24] rounded-xl overflow-hidden border border-transparent hover:border-purple-500/30 transition-all group cursor-pointer"
              onClick={() => setSelectedLog(log)}
            >
              {/* Thumbnail */}
              <div className="relative aspect-video bg-[#0a0a0f] overflow-hidden">
                <img
                  src={log.thumbnail}
                  alt="Deleted media"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <span className="text-white text-lg font-medium flex items-center gap-2">
                    👁️ View
                  </span>
                </div>
                <div className={`absolute top-2 left-2 px-2 py-1 rounded-lg text-xs font-medium text-white bg-gradient-to-r ${getTypeColor(log.type)}`}>
                  {getTypeIcon(log.type)} {log.type.toUpperCase()}
                </div>
              </div>
              
              {/* Info */}
              <div className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-white font-medium text-sm">{log.user}</span>
                  <span className="text-gray-500 text-xs">{log.channel}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-red-400 text-xs">{log.reason}</span>
                  <span className="text-gray-600 text-xs">{log.deletedAt.split(' ')[1]}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredLogs.length === 0 && (
          <div className="text-center py-12">
            <span className="text-4xl mb-4 block">📸</span>
            <p className="text-gray-400">No media logs found</p>
          </div>
        )}
      </div>

      {/* View Modal */}
      {selectedLog && (
        <div 
          className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedLog(null)}
        >
          <div 
            className="bg-[#12121a] rounded-2xl w-full max-w-2xl border border-purple-500/30 overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Image */}
            <div className="relative aspect-video bg-[#0a0a0f]">
              <img
                src={selectedLog.url}
                alt="Deleted media"
                className="w-full h-full object-contain"
              />
              <button
                onClick={() => setSelectedLog(null)}
                className="absolute top-4 right-4 w-10 h-10 bg-black/50 rounded-full flex items-center justify-center text-white hover:bg-black/70 transition-colors"
              >
                ✕
              </button>
            </div>
            
            {/* Details */}
            <div className="p-6 space-y-4">
              <div className="flex items-center gap-3">
                <span className={`px-3 py-1 rounded-lg text-sm font-medium text-white bg-gradient-to-r ${getTypeColor(selectedLog.type)}`}>
                  {getTypeIcon(selectedLog.type)} {selectedLog.type.toUpperCase()}
                </span>
                <span className="text-red-400 text-sm">{selectedLog.reason}</span>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-500 mb-1">User</p>
                  <p className="text-white">{selectedLog.user}</p>
                  <p className="text-gray-600 text-xs">ID: {selectedLog.userId}</p>
                </div>
                <div>
                  <p className="text-gray-500 mb-1">Channel</p>
                  <p className="text-white">{selectedLog.channel}</p>
                </div>
                <div>
                  <p className="text-gray-500 mb-1">Deleted At</p>
                  <p className="text-white">{selectedLog.deletedAt}</p>
                </div>
                <div>
                  <p className="text-gray-500 mb-1">Deleted By</p>
                  <p className="text-white">{selectedLog.deletedBy}</p>
                </div>
              </div>
              
              <div className="flex gap-3 pt-4 border-t border-purple-500/20">
                <a
                  href={selectedLog.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-3 rounded-xl font-medium text-center hover:opacity-90 transition-opacity"
                >
                  ⬇️ Download Original
                </a>
                <button
                  onClick={() => setSelectedLog(null)}
                  className="flex-1 bg-gray-700 text-white px-4 py-3 rounded-xl font-medium hover:bg-gray-600 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
