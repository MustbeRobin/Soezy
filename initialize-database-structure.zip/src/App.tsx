import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Dashboard } from './pages/Dashboard';
import { Commands } from './pages/Commands';
import { AutoResponder } from './pages/AutoResponder';
import { MediaLogs } from './pages/MediaLogs';
import { StickerSteal } from './pages/StickerSteal';
import { Settings } from './pages/Settings';

export type Page = 'dashboard' | 'commands' | 'autoresponder' | 'medialogs' | 'stickersteal' | 'settings';

export function App() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard />;
      case 'commands':
        return <Commands />;
      case 'autoresponder':
        return <AutoResponder />;
      case 'medialogs':
        return <MediaLogs />;
      case 'stickersteal':
        return <StickerSteal />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="flex min-h-screen bg-[#0a0a0f]">
      <Sidebar 
        currentPage={currentPage} 
        setCurrentPage={setCurrentPage} 
        isOpen={sidebarOpen}
        setIsOpen={setSidebarOpen}
      />
      <div className="flex-1 flex flex-col lg:ml-64">
        <Header setSidebarOpen={setSidebarOpen} />
        <main className="flex-1 p-4 lg:p-6 overflow-auto">
          {renderPage()}
        </main>
      </div>
    </div>
  );
}
