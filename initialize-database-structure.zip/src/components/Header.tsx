interface HeaderProps {
  setSidebarOpen: (open: boolean) => void;
}

export function Header({ setSidebarOpen }: HeaderProps) {
  return (
    <header className="bg-[#12121a]/80 backdrop-blur-xl border-b border-purple-500/20 p-4 sticky top-0 z-30">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden text-gray-400 hover:text-white p-2"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
          <div>
            <h2 className="text-white font-semibold text-lg">Bot Dashboard</h2>
            <p className="text-gray-500 text-sm">Manage your Discord bot</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="hidden sm:flex items-center gap-2 bg-[#1a1a24] rounded-xl px-4 py-2 border border-purple-500/20">
            <span className="text-gray-400 text-sm">Prefix:</span>
            <code className="text-purple-400 font-mono">!</code>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
              <span className="text-white font-bold">S</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
